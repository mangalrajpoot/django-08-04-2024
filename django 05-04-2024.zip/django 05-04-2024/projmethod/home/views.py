from django.shortcuts import render
from .models import User

# Create your views here.
def index(request):
    if request.method=='GET':
        return render(request,'home/index.html')
    else:
        fullname=request.POST['fullname']
        email=request.POST['email']
        password=request.POST['password']
        g=request.POST['g']
        c=request.POST.getlist('c')
        state=request.POST['state']
        data=User(fullname=fullname, email=email, password=password,gender=g,course=c, state=state)
        data.save()
        return render(request,'home/index.html',{'m':'Data Saved !'})
    


def read(request):
    getdata=User.objects.all() #Select * from User
    return render(request,'home/read.html',{'data':getdata})
